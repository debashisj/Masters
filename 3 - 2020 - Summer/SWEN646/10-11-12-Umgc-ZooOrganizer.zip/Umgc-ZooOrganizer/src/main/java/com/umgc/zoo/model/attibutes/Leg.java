package com.umgc.zoo.model.attibutes;

public class Leg {
    private float length;

    public Leg() {
    }

    public Leg(float length) {
        this.length = length;
    }

    public float getLength() {
        return length;
    }

    public void setLength(float length) {
        this.length = length;
    }
}
