package com.umgc.zoo.model.attibutes;

public class Scale {
    private String color;

    public Scale() {
    }

    public Scale(String featherColor) {
        this.color = featherColor;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }
}
