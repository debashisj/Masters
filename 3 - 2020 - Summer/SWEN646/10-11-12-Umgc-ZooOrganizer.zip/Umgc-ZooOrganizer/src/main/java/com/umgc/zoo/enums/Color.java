package com.umgc.zoo.enums;

public enum Color {
        RED, GREEN, BLUE
}
