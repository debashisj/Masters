package com.umgc.addressbook.service;

import com.umgc.addressbook.model.Contact;
import com.umgc.addressbook.util.AddressBookAppUtil;
import org.apache.commons.lang3.StringUtils;

import java.util.List;
import java.util.Scanner;

public class AddressBookAppService {

    public void addContact(Scanner input) {
        Contact contact = new Contact();
        setContactFields(contact, input);
        try {
            AddressBookAppUtil.addContactsToMasterFile(contact);
            AddressBookAppUtil.printAllContacts();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public Contact deleteContact(Scanner input) {
        List<Contact> contacts = AddressBookAppUtil.printAllContacts();
        int index = getSelectedContactId(contacts, input);
        if(index == -1) {
            return null;
        }
        Contact selectedContact = contacts.get(index);
        System.out.println("You selected the following contact. \n" + selectedContact.toString());
        System.out.println("Are you sure? y/n");
        String inputStr = input.nextLine();
        if("y".equalsIgnoreCase(inputStr) || "yes".equalsIgnoreCase(inputStr)) {
            contacts.remove(index);
            AddressBookAppUtil.saveToMasterFile(contacts);
        } else {
            System.out.println("That's ok, you are not ready yet. Cancelling.");
        }
        return selectedContact;
    }

    public Contact editContact(Scanner input) {
        List<Contact> contacts = AddressBookAppUtil.printAllContacts();
        int index = getSelectedContactId(contacts, input);
        if(index == -1) {
            return null;
        }
        Contact selectedContact = contacts.get(index);
        System.out.println("You selected the following contact. Please enter the new details.\n" + selectedContact.toString());

        for(int i=0; i<contacts.size(); i++) {
            if(i == index) {
                setContactFields(contacts.get(i), input);
            }
        }
        AddressBookAppUtil.saveToMasterFile(contacts);
        return selectedContact;
    }

    public void viewContacts() {
        AddressBookAppUtil.printAllContacts();
    }

    private String getElementFromInput(String elementName, Scanner input) {
        System.out.println("Enter the " + elementName);
        String elementValue;
        while(true) {
            elementValue = input.nextLine();
            if (StringUtils.isEmpty(elementValue)) {
                System.out.println("Invalid input. Enter the " + elementName + " again");
            } else {
                break;
            }
        }
        return elementValue;
    }

    private void setContactFields(Contact contact, Scanner input) {
        contact.setName(getElementFromInput("name", input));
        contact.setStreet(getElementFromInput("street", input));
        contact.setCity(getElementFromInput("city", input));
        contact.setZip(getElementFromInput("zip", input));
        contact.setState(getElementFromInput("state", input));
        contact.setPhoneNumber(getElementFromInput("phone number", input));
    }

    private int getSelectedContactId(List<Contact> contacts, Scanner input) {
        if(contacts == null || contacts.isEmpty()) {
            System.out.println("No contacts in the address book.");
            return -1;
        }
        System.out.println("Select the contact id...");
        int selectedId;
        while(true) {
            try {
                String selectedIdStr = input.nextLine();
                selectedId = Integer.parseInt(selectedIdStr);
                int numberOfRecords = contacts.size();

                if (selectedId < 0 || selectedId > numberOfRecords) {
                    System.out.println("Invalid id. Please enter a value between 1 and " + numberOfRecords);
                } else {
                    break;
                }
            } catch (NumberFormatException ex) {
                System.out.println("Invalid entry for an integer...");
            }
        }
        return selectedId - 1;
    }
}
