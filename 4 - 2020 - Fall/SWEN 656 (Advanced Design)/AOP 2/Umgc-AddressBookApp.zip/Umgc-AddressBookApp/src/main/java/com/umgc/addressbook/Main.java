package com.umgc.addressbook;

import com.umgc.addressbook.service.AddressBookAppService;

import java.util.Scanner;

public class Main {
    private static final Scanner input = new Scanner(System.in);

    public static void main(String[] args) {
        AddressBookAppService service = new AddressBookAppService();
        while (true) {
            System.out.println("\n-------------------------------------------------------------------------------------------------------------------------------------");
            System.out.println("ADDRESS BOOK - Type a or add / d or delete / e or edit / v or view. Exit to exit..");
            String inputString = input.nextLine();
            if ("exit".equalsIgnoreCase(inputString)) {
                return;
            }

            switch (inputString) {
                case "add":
                case "a":
                    service.addContact(input);
                    break;
                case "delete":
                case "d":
                    service.deleteContact(input);
                    break;
                case "edit":
                case "e":
                    service.editContact(input);
                    break;
                case "view":
                case "v":
                    service.viewContacts();
                    break;
                default:
                    System.out.println("Invalid input. Try again...");
                    break;
            }
            break;
        }
    }
}
