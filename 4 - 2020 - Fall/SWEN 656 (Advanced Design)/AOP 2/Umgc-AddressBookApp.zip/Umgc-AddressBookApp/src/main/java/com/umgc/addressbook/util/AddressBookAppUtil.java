package com.umgc.addressbook.util;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.core.util.DefaultPrettyPrinter;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.umgc.addressbook.model.Contact;
import org.json.simple.parser.JSONParser;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class AddressBookAppUtil {

    public static final String MASTER_ADDRESS_BOOK_FILE_JSON = "MasterFile.json";

    public AddressBookAppUtil() {
    }

    public static List<Contact> getContactsFromJsonFile(String fileName) {
        Object obj = getObjectFromJson(fileName);
        obj = Objects.nonNull(obj) ? obj : new ArrayList<>();
        try {
            return getMapper().readValue(obj.toString(), new TypeReference<List<Contact>>(){});
        } catch (IOException e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }

    public static String getResourcePath(String fileName) {
        return System.getProperty("user.dir") + "/src/main/resources/" + fileName;
    }

    public static void saveToMasterFile(Object object) {
        saveToFile(object, MASTER_ADDRESS_BOOK_FILE_JSON);
    }

    public static void saveToFile(Object object, String fileName) {
        ObjectMapperContextResolver mapperResolver = new ObjectMapperContextResolver();
        ObjectMapper mapper = mapperResolver.getContext(Contact.class);
        ObjectWriter writer = mapper.writer(new DefaultPrettyPrinter());
        try {
            writer.writeValue(new File(AddressBookAppUtil.getResourcePath(fileName)), object);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void addContactsToMasterFile(Contact newContact) {
        List<Contact> contacts = getContactsFromJsonFile(MASTER_ADDRESS_BOOK_FILE_JSON);

        if(Objects.isNull(contacts)) {
            contacts = new ArrayList<>();
        }
        contacts.add(newContact);
        saveToFile(contacts, MASTER_ADDRESS_BOOK_FILE_JSON);
    }

    public static List<Contact> printAllContacts() {
        List<Contact> contacts = getContactsFromJsonFile(MASTER_ADDRESS_BOOK_FILE_JSON);
        System.out.println("Total number of contacts: " + (Objects.nonNull(contacts) ? contacts.size() : 0));
        if(Objects.nonNull(contacts) && !contacts.isEmpty()) {
            System.out.println("All contacts: ");
            for(int i = 0; i < contacts.size(); i++) {
                contacts.get(i).printContactWithIndex(i);
                System.out.println();
            }
            return contacts;
        } else {
            System.out.println("No contacts in the list.");
            return new ArrayList<>();
        }
    }

    private static Object getObjectFromJson(String fileName) {
        JSONParser jsonParser = new JSONParser();
        Object obj = null;
        try {
            FileReader reader = new FileReader (getResourcePath(fileName));
            obj = jsonParser.parse(reader);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return obj;
    }

    private static ObjectMapper getMapper() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        return mapper;
    }

    public static void saveLog(String log) throws IOException {
        String fileName = getResourcePath("ChangeLog.txt");

        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String formatDateTime = now.format(formatter);

        FileWriter fw = new FileWriter(fileName, true);
        BufferedWriter bw = new BufferedWriter(fw);
        bw.write(formatDateTime + " : " + log);
        bw.newLine();
        bw.close();
    }
}
