package com.umgc.addressbook.model;

public class Contact {
    private String name;
    private String street;
    private String city;
    private String state;
    private String zip;
    private String phoneNumber;

    public void printContactWithIndex(int index) {
        System.out.format("%5d%20s%20s%15s%5s%9s%16s",
                index+1,
                this.name,
                this.street,
                this.city,
                this.state,
                this.zip,
                this.phoneNumber);
    }

    @Override
    public String toString() {
        return name + "\t\t" +
                street + ", " +
                city + " " +
                state + " " +
                zip + "\t" +
                phoneNumber;
    }
    public String toLogString() {
        return "Contact [Name = " + name + ", Street = " + street + ", City = " + city + ", State = " + state +
                ", Zip = " + zip + ", Phone Number = " + phoneNumber + "]";
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
}
