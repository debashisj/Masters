package com.umgc.addressbook;

import com.umgc.addressbook.model.Contact;
import com.umgc.addressbook.util.AddressBookAppUtil;
import org.junit.Assert;
import org.junit.Test;

import java.util.List;

import static com.umgc.addressbook.util.AddressBookAppUtil.MASTER_ADDRESS_BOOK_FILE_JSON;

public class MyUnitTestsTest {

    @Test
    public void viewContactTest() {
        List<Contact> contacts = AddressBookAppUtil.getContactsFromJsonFile(MASTER_ADDRESS_BOOK_FILE_JSON);
        int beforeCount = contacts.size();

        contacts.add(new Contact());
        Assert.assertEquals( beforeCount + 1, contacts.size());
    }
}
