#UMGC - Address Book App (AspectJ)


##Description
Address book application can store Name, Street, City, State, ZIP and phone number.
The main features to to:
- Add an contact to the address book
- Delete a contact from the address book
- Update a contact from the address book
- Display the address book

It uses AspectJ which saves the log when the user updates a contact the previous data is written to a file. 
Similarly, when the user deletes a contact, the activity log gets saved to the file.


##How to execute?
Execute the main class and follow along the instructions printed in the console.
For each of the functions (add/edit/delete/view), you can either use the whole word or just the initial.
For example, to view all contacts, you may type 'view' or just 'v'. 
