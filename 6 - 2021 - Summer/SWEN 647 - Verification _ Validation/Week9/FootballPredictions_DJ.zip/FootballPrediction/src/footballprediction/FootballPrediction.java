/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package footballprediction;
import java.util.*;
/**
 *
 * @author mbrown15
 */
public class FootballPrediction {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int homeGamesWon;
        int visitingGamesWon;
        
        System.out.println("Welcome to UMUCs football prediction tool.");
        System.out.println("Enter of the home team of that game that you would like us to predict.");
        Scanner scanstr = new Scanner (System.in, "UTF-8");
        Scanner scanint = new Scanner (System.in, "UTF-8");
        String HomeTeam = scanstr.nextLine();
        
        System.out.println("Enter of the visiting team of that game that you would like us to predict.");
        String VisitingTeam = scanstr.nextLine();
        
        System.out.println("How many points did " + HomeTeam + " score in their previous game?");
        int homePreviousScore = scanint.nextInt();
        
        System.out.println("How many points did " + VisitingTeam + " score in their previous game?");
        int visitingPreviousScore = scanint.nextInt();
        
        System.out.println("How many games did " + HomeTeam + " win this year??");
        homeGamesWon = scanint.nextInt();
        
        System.out.println("How many games did " + VisitingTeam + " win this year?");
        visitingGamesWon = scanint.nextInt();
       
        System.out.println("\nWe predicts that the " + 
                predictWinner(HomeTeam, VisitingTeam, homePreviousScore, visitingPreviousScore,
                        homeGamesWon, visitingGamesWon) + " will win.");
        
    }
    
    public static String predictWinner(String homeTeam, String visitingTame, int homePoints,
            int visitingPoints, int homeWins, int visitingWins)
    {
        float home = (homePoints - visitingPoints + 3) / (float)(visitingWins + 1);
        float visiting = (visitingPoints - homePoints) / (float) (homeWins + 1);
        
        if (home >= visiting)
            return homeTeam;
        else 
            return visitingTame;
    }
}
