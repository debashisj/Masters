/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
    function makeHttpObject() {
                try {return new XMLHttpRequest();}
                   catch (error) {alert("error");}
                try {return new ActiveXObject("Msxml2.XMLHTTP");}
                   catch (error) {alert("error");}
                try {return new ActiveXObject("Microsoft.XMLHTTP");}
                   catch (error) {alert("error");}
                throw new Error("Could not create HTTP request object.");
                }
                
    function refreshVOINoFilter(){
        window.location.href = 'index.html';
    }
    
               
    function refreshVOIWithFilter(){
        const filter = new URLSearchParams(window.location.search).get('filter');
        setData(filter);
    }
    
    function searchVOI(e){
        const filterValue = e.value;
        //if(filterValue.length >= 3) {
            setData(filterValue);
        //}
    }
    
    function setData(filter){  
        
        // Find a <table> element with id="VOITable":
        var VOITable = document.getElementById("VOITable");
        var tableRows = VOITable.getElementsByTagName('tr');   
        var rowCount = VOITable.rows.length;
        for (var r = 1; r < rowCount; r++) {
            VOITable.deleteRow(-1);
         }
         
        var request = makeHttpObject();
        var xmlDoc;
        var parser;
        var x, i;
        var vois, voi;
        request.open("GET", "http://localhost:8080/VehiclesOfInterestWebServices/webresources/model.vehicleofinterest", true);
        request.send();
        request.onreadystatechange = function() {

            if (request.readyState === 4) {               
               parser = new DOMParser();
               vois = parser.parseFromString(request.responseText.toString(),"text/xml");
               voi = vois.documentElement.childNodes;

               for (i = 0; i < voi.length; i++) {
                  const licensePlate = vois.getElementsByTagName("licensePlate")[i].childNodes[0].nodeValue;
                  if(filter && (!licensePlate || licensePlate.toLowerCase().indexOf(filter.toLowerCase()) < 0)) {
                      continue;
                  }
                  var row = VOITable.insertRow(-1);
                  
                  // Insert new cells (<td> elements) at the 1st and 2nd position of the "new" <tr> element:
                  var cell1 = row.insertCell(0);
                  var cell2 = row.insertCell(1);
                  var cell3 = row.insertCell(2);
                  var cell4 = row.insertCell(3);
                  var cell5 = row.insertCell(4);
                  var cell6 = row.insertCell(5);
                  var cell7 = row.insertCell(6);
                  var cell8 = row.insertCell(7);
                  var cell9 = row.insertCell(8);

                  // Add some text to the new cells:
                  cell1.innerHTML = licensePlate;
                  cell2.innerHTML = vois.getElementsByTagName("reason")[(i*2) + 1].childNodes[0].nodeValue;
                  cell3.innerHTML = vois.getElementsByTagName("make")[(i*4)+1].childNodes[0].nodeValue;
                  cell4.innerHTML = vois.getElementsByTagName("model")[(i*2)+1].childNodes[0].nodeValue;
                  cell5.innerHTML = vois.getElementsByTagName("vehYear")[i].childNodes[0].nodeValue;
                  cell6.innerHTML = vois.getElementsByTagName("color")[i].childNodes[0].nodeValue;
                  cell7.innerHTML = vois.getElementsByTagName("ownersName")[i].childNodes[0].nodeValue;
                  cell8.innerHTML = vois.getElementsByTagName("ownersPhone")[i].childNodes[0].nodeValue;
                  
                  var linkUrl = 'location.href=\'detail.html?plate=' + licensePlate;
                  
                  if(filter) {
                      linkUrl += ('&filter=' + filter);
                  }
                  cell9.innerHTML = '<input id="Button" type="button" value="View" onClick=' + linkUrl + '\'>';
                  
              } // end of for loop
            }  // end of if statement
            request.close();
              
          }; // end of fucntion
    } // end of refreshSales function
   
    function goBack(){
        const filter = new URLSearchParams(window.location.search).get('filter');
        var homeUrl = 'index.html';
        if(filter) {
            homeUrl += '?filter=' + filter;
        }
        window.location.href = homeUrl;
    }
    
    function viewRecord(){  
        const plateNum = new URLSearchParams(window.location.search).get('plate');
        var VehicleDetail = document.getElementById("VehicleDetail");
        var tableRows = VehicleDetail.getElementsByTagName('tr');   
        var rowCount = VehicleDetail.rows.length;
        for (var r = 1; r < rowCount; r++) {
            VehicleDetail.deleteRow(-1);
         }
         
        var request = makeHttpObject();
        var xmlDoc;
        var parser;
        var x, i;
        var vois, voi;
        request.open("GET", "http://localhost:8080/VehiclesOfInterestWebServices/webresources/model.vehicleofinterest", true);
        request.send();
        request.onreadystatechange = function() {

            if (request.readyState === 4) {               
               parser = new DOMParser();
               vois = parser.parseFromString(request.responseText.toString(),"text/xml");
               voi = vois.documentElement.childNodes;
               var licensePlate, reason, make, model, vehYear, color, ownersName, ownersPhone;
               
               for (i = 0; i < voi.length; i++) {
                  licensePlate = vois.getElementsByTagName("licensePlate")[i].childNodes[0].nodeValue;
                  if(plateNum && (!licensePlate || licensePlate.toLowerCase() !== plateNum.toLowerCase())) {
                      continue;
                  }
                  var row = VehicleDetail.insertRow(-1);
                  
                  reason = vois.getElementsByTagName("reason")[(i*2) + 1].childNodes[0].nodeValue;
                  make = vois.getElementsByTagName("make")[(i*4)+1].childNodes[0].nodeValue;
                  model = vois.getElementsByTagName("model")[(i*2)+1].childNodes[0].nodeValue;
                  vehYear = vois.getElementsByTagName("vehYear")[i].childNodes[0].nodeValue;
                  color = vois.getElementsByTagName("color")[i].childNodes[0].nodeValue;
                  ownersName = vois.getElementsByTagName("ownersName")[i].childNodes[0].nodeValue;
                  ownersPhone = vois.getElementsByTagName("ownersPhone")[i].childNodes[0].nodeValue;  
                  break;
                  
              } // end of for loop
              
              
              var row = VehicleDetail.insertRow(-1);
              row.insertCell(0).innerHTML = '<i>License Plate</i>';
              row.insertCell(1).innerHTML = licensePlate;
              
              row = VehicleDetail.insertRow(-1);
              row.insertCell(0).innerHTML = '<i>Reason</i>';
              row.insertCell(1).innerHTML = reason;
              
              row = VehicleDetail.insertRow(-1);
              row.insertCell(0).innerHTML = '<i>Make</i>';
              row.insertCell(1).innerHTML = make;
              
              row = VehicleDetail.insertRow(-1);
              row.insertCell(0).innerHTML = '<i>Model</i>';
              row.insertCell(1).innerHTML = model;
              
              row = VehicleDetail.insertRow(-1);
              row.insertCell(0).innerHTML = '<i>Year</i>';
              row.insertCell(1).innerHTML = vehYear;
              
              row = VehicleDetail.insertRow(-1);
              row.insertCell(0).innerHTML = '<i>Vehicle Color</i>';
              row.insertCell(1).innerHTML = color;
              
              row = VehicleDetail.insertRow(-1);
              row.insertCell(0).innerHTML = '<i>Owner\'s Name</i>';
              row.insertCell(1).innerHTML = ownersName;
              
              row = VehicleDetail.insertRow(-1);
              row.insertCell(0).innerHTML = '<i>Owner\'s Phone</i>';
              row.insertCell(1).innerHTML = ownersPhone;
            }  // end of if statement
            request.close();
              
          }; // end of fucntion
        
    }